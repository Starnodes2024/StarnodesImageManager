#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import subprocess
import platform

# Define colors for terminal output
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

def print_step(message):
    """Print a formatted step message"""
    print(f"{Colors.HEADER}[SETUP]{Colors.ENDC} {Colors.BOLD}{message}{Colors.ENDC}")

def print_success(message):
    """Print a formatted success message"""
    print(f"{Colors.GREEN}[SUCCESS]{Colors.ENDC} {message}")

def print_error(message):
    """Print a formatted error message"""
    print(f"{Colors.FAIL}[ERROR]{Colors.ENDC} {message}")

def print_warning(message):
    """Print a formatted warning message"""
    print(f"{Colors.WARNING}[WARNING]{Colors.ENDC} {message}")

def create_virtual_environment():
    """Create a Python virtual environment"""
    venv_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "venv")
    
    print_step("Creating Python virtual environment...")
    
    try:
        # Check if venv already exists
        if os.path.exists(venv_dir):
            print_warning(f"Virtual environment already exists at: {venv_dir}")
            choice = input("Do you want to recreate it? (y/n): ").lower().strip()
            if choice == 'y':
                import shutil
                shutil.rmtree(venv_dir)
            else:
                print_warning("Skipping virtual environment creation.")
                return venv_dir
        
        # Create venv
        subprocess.check_call([sys.executable, "-m", "venv", venv_dir])
        print_success(f"Virtual environment created at: {venv_dir}")
        return venv_dir
    except subprocess.CalledProcessError as e:
        print_error(f"Failed to create virtual environment: {e}")
        sys.exit(1)

def install_dependencies(venv_dir):
    """Install dependencies in the virtual environment"""
    print_step("Installing dependencies...")
    
    # Get the python executable from the venv
    if platform.system() == "Windows":
        python_exe = os.path.join(venv_dir, "Scripts", "python.exe")
        pip_exe = os.path.join(venv_dir, "Scripts", "pip.exe")
    else:
        python_exe = os.path.join(venv_dir, "bin", "python")
        pip_exe = os.path.join(venv_dir, "bin", "pip")
    
    requirements_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "requirements.txt")
    
    try:
        # Upgrade pip
        subprocess.check_call([python_exe, "-m", "pip", "install", "--upgrade", "pip"])
        
        # Install requirements
        subprocess.check_call([pip_exe, "install", "-r", requirements_file])
        
        print_success("Dependencies installed successfully")
    except subprocess.CalledProcessError as e:
        print_error(f"Failed to install dependencies: {e}")
        sys.exit(1)

def create_start_script(venv_dir):
    """Create the start script for the application"""
    print_step("Creating start script...")
    
    # Get the path to the python executable in the venv
    if platform.system() == "Windows":
        python_path = os.path.join(venv_dir, "Scripts", "python.exe")
        start_script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "2_START_BUDDY.bat")
        
        with open(start_script, "w") as f:
            f.write("@echo off\n")
            f.write("echo Starting StarBuddy...\n")
            f.write(f'"{python_path}" starbuddy.py\n')
            f.write("if errorlevel 1 (\n")
            f.write("  echo Error starting StarBuddy\n")
            f.write("  pause\n")
            f.write(")\n")
    else:
        python_path = os.path.join(venv_dir, "bin", "python")
        start_script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "2_START_BUDDY.sh")
        
        with open(start_script, "w") as f:
            f.write("#!/bin/bash\n")
            f.write("echo Starting StarBuddy...\n")
            f.write(f'"{python_path}" starbuddy.py\n')
        
        # Make the script executable on Unix
        os.chmod(start_script, 0o755)
    
    print_success(f"Start script created at: {start_script}")

def main():
    print(f"\n{Colors.BOLD}{Colors.BLUE}StarBuddy Setup{Colors.ENDC}\n")
    
    # Create virtual environment
    venv_dir = create_virtual_environment()
    
    # Install dependencies
    install_dependencies(venv_dir)
    
    # Create start script
    create_start_script(venv_dir)
    
    print(f"\n{Colors.BOLD}{Colors.GREEN}Setup completed successfully!{Colors.ENDC}")
    print(f"You can now start StarBuddy using the start script 2_START_BUDDY.\n")

if __name__ == "__main__":
    main()
