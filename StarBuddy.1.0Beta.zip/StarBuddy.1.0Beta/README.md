# StarBuddy

StarBuddy is a personal AI chat agent with a messenger-like interface that connects to local Ollama models.

## Current Features

- Modern messenger-like GUI interface
- Integration with local Ollama models
- Model selection from available Ollama models
- Custom system prompt configuration
- Settings management
- Framework for long-term memory storage

## In Development

- Improved file upload for PDF and TXT (currently partial implementation)
- Image upload for vision models (currently placeholder)
- Theme system with multiple visual styles
- Enhanced memory management

## Requirements

- Python 3.8+
- Ollama running locally
- Required Python packages (see requirements.txt)

## Installation

### Automatic Setup (Recommended)

1. Clone this repository
2. Run the setup script to create a virtual environment and install dependencies:
   ```
   python setup.py
   ```
3. Ensure Ollama is installed and running on your system

### Manual Installation

1. Clone this repository
2. Create a virtual environment (optional but recommended):
   ```
   python -m venv venv
   ```
3. Activate the virtual environment:
   - Windows: `venv\Scripts\activate`
   - Linux/Mac: `source venv/bin/activate`
4. Install required dependencies:
   ```
   pip install -r requirements.txt
   ```
5. Ensure Ollama is installed and running on your system

## Usage

### Easy Start (Windows)

Double-click the `start.bat` file to launch the application.

### Manual Start

Run the application:
```
python starbuddy.py
```

## Known Issues

1. The application cannot properly read and process uploaded TXT and PDF files to send their content to the conversation
2. Image upload for vision models is not fully implemented
3. No theme system yet for different visual preferences

Please see progress.md for a detailed development roadmap.

## License

MIT
