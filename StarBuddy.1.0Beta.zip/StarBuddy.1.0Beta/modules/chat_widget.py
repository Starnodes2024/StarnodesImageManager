#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import datetime
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QTextEdit, 
                            QLineEdit, QPushButton, QLabel, QFileDialog,
                            QScrollArea, QFrame, QMenu, QMessageBox, QApplication)
from PyQt6.QtGui import QFont, QIcon, QPixmap, QTextCursor, QAction, QTextOption
from .config_manager import load_config
from PyQt6.QtCore import Qt, QSize, QThread, pyqtSignal, QMimeData
from .voice_utils import VoiceInput, VoiceOutput
import threading
from PyQt6.QtCore import pyqtSignal

class ChatThread(QThread):
    """Thread for handling chat requests to avoid UI freezing"""
    response_received = pyqtSignal(str)
    error_occurred = pyqtSignal(str)
    
    def __init__(self, api, prompt, model, system_prompt):
        super().__init__()
        self.api = api
        self.prompt = prompt
        self.model = model
        self.system_prompt = system_prompt
        
    def run(self):
        try:
            response = self.api.generate_response(
                prompt=self.prompt,
                model=self.model,
                system_prompt=self.system_prompt,
                stream=True
            )
            if response:
                self.response_received.emit(response)
        except Exception as e:
            self.error_occurred.emit(str(e))


class MessageBubble(QFrame):
    """Custom widget for chat message bubbles"""
    def __init__(self, message, is_user=True, name=None, avatar_path=None, parent=None, image_path=None):
        super().__init__(parent)
        self.is_user = is_user
        self.name = name or ("You" if is_user else "StarBuddy")
        self.avatar_path = avatar_path
        self.image_path = image_path
        self.init_ui(message)
        
    def init_ui(self, message):
        from PyQt6.QtWidgets import QHBoxLayout, QVBoxLayout, QLabel
        from PyQt6.QtGui import QPixmap, QPainter, QBrush, QColor, QFont
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # Set frame style
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setFrameShadow(QFrame.Shadow.Raised)
        
        # Avatar
        avatar_label = QLabel()
        avatar_label.setFixedSize(100, 100)
        avatar_label.setScaledContents(True)
        if self.avatar_path and os.path.exists(self.avatar_path):
            pixmap = QPixmap(self.avatar_path).scaled(100, 100)
            # Make round avatar
            mask = QPixmap(100, 100)
            mask.fill(QColor("transparent"))
            painter = QPainter(mask)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            painter.setBrush(QBrush(pixmap))
            painter.setPen(QColor("transparent"))
            painter.drawEllipse(0, 0, 100, 100)
            painter.end()
            avatar_label.setPixmap(mask)
        else:
            # Default avatar (colored circle with initial)
            pixmap = QPixmap(100, 100)
            pixmap.fill(QColor("#bdbdbd" if self.is_user else "#9575cd"))
            painter = QPainter(pixmap)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            painter.setPen(QColor("transparent"))
            painter.setBrush(QBrush(QColor("#bdbdbd" if self.is_user else "#9575cd")))
            painter.drawEllipse(0, 0, 100, 100)
            painter.setPen(QColor("white"))
            painter.setFont(QFont("Segoe UI", 48, QFont.Weight.Bold))
            painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, self.name[0] if self.name else "?")
            painter.end()
            avatar_label.setPixmap(pixmap)
        
        # Name label
        name_label = QLabel(self.name)
        name_label.setStyleSheet("font-weight: bold; font-size: 18px; margin-bottom: 6px;")
        
        # Message display
        msg_layout = QVBoxLayout()
        msg_layout.setContentsMargins(0, 0, 0, 0)
        msg_layout.addWidget(name_label)
        # If image_path is provided, show a thumbnail
        if self.image_path and os.path.exists(self.image_path):
            image_label = QLabel()
            pixmap = QPixmap(self.image_path)
            if not pixmap.isNull():
                pixmap = pixmap.scaled(250, 250, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                image_label.setPixmap(pixmap)
                image_label.setFixedSize(pixmap.size())
                msg_layout.addWidget(image_label)
        self.message_display = QLabel()
        self.message_display.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.message_display.setWordWrap(True)
        self.message_display.setText(message)
        self.message_display.setMinimumWidth(300)
        from PyQt6.QtWidgets import QSizePolicy
        self.message_display.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        # Set chat-bubble property for QSS styling
        self.message_display.setProperty("chat-bubble", "user" if self.is_user else "bot")
        self.message_display.setStyleSheet("font-size: 18px; padding: 14px 18px;")
        msg_layout.addWidget(self.message_display)
        # Bubble style: only border-radius, margin, and padding (no box-shadow)
        self.setStyleSheet("")
        if self.is_user:
            layout.setAlignment(Qt.AlignmentFlag.AlignRight)
        else:
            layout.setAlignment(Qt.AlignmentFlag.AlignLeft)
        if self.is_user:
            layout.addStretch()
            layout.addLayout(msg_layout)
            layout.addWidget(avatar_label)
        else:
            layout.addWidget(avatar_label)
            layout.addLayout(msg_layout)
            layout.addStretch()
        self.setSizePolicy(self.message_display.sizePolicy())


class ChatWidget(QWidget):
    """Widget for the chat interface"""
    voice_input_complete = pyqtSignal(str, str)  # (text, status_msg)

    def __init__(self, ollama_api, memory_manager, parent=None):
        super().__init__(parent)
        self.ollama_api = ollama_api
        self.memory_manager = memory_manager
        self.config = load_config()
        self.current_model = self.config.get("model", "")
        self.system_prompt = self.config.get("system_prompt", "You are a helpful AI assistant.")
        self.chat_history = []
        self.show_thinking = self.config.get("show_thinking", True)
        self.init_ui()
        # Connect voice input signal
        self.voice_input_complete.connect(self._set_voice_input_text)

        # Enable drag-and-drop for images
        self.setAcceptDrops(True)

        # Connect API signals
        self.ollama_api.response_chunk.connect(self.on_response_chunk)
        self.ollama_api.error_occurred.connect(self.on_api_error)
        # Connect memory error signal
        if hasattr(self.memory_manager, 'memory_error'):
            self.memory_manager.memory_error.connect(self.on_memory_error)
        if hasattr(self.memory_manager, 'memory_updated'):
            self.memory_manager.memory_updated.connect(self.on_memory_updated)

    def on_memory_error(self, error_msg):
        QMessageBox.critical(self, "Memory Error", f"Long-term memory error: {error_msg}", QMessageBox.StandardButton.Ok)
        self.status_bar.setText(f"Memory Error: {error_msg}")

    def on_memory_updated(self):
        self.status_bar.setText("Long-term memory updated.")

        
    def init_ui(self):
        """Initialize the chat widget UI"""
        layout = QVBoxLayout(self)

        # Chat display area
        self.chat_area = QScrollArea()
        self.chat_area.setWidgetResizable(True)
        self.chat_area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

        # Container for chat messages
        self.chat_container = QWidget()
        self.chat_layout = QVBoxLayout(self.chat_container)
        self.chat_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.chat_layout.setSpacing(10)
        self.chat_layout.setContentsMargins(10, 10, 10, 10)
        self.chat_area.setWidget(self.chat_container)

        # Input area
        input_layout = QHBoxLayout()

        # File upload button
        self.upload_btn = QPushButton()
        self.upload_btn.setIcon(QIcon.fromTheme("document-open"))
        self.upload_btn.setToolTip("Upload a file")
        self.upload_btn.clicked.connect(self.on_upload_file)

        # Voice input button
        self.voice_btn = QPushButton()
        self.voice_btn.setIcon(QIcon.fromTheme("media-record"))
        self.voice_btn.setToolTip("Voice input (speech-to-text)")
        self.voice_btn.clicked.connect(self.on_voice_input)

        # Search Memory button
        self.search_memory_btn = QPushButton()
        self.search_memory_btn.setIcon(QIcon.fromTheme("edit-find"))
        self.search_memory_btn.setToolTip("Search Memory")
        self.search_memory_btn.clicked.connect(self.on_search_memory)

        # Clear Memory button
        self.clear_memory_btn = QPushButton()
        self.clear_memory_btn.setIcon(QIcon.fromTheme("edit-clear"))
        self.clear_memory_btn.setToolTip("Clear Memory")
        self.clear_memory_btn.clicked.connect(self.on_clear_memory)

        # Text input field
        self.message_input = QLineEdit()
        self.message_input.setPlaceholderText("Type a message...")
        self.message_input.returnPressed.connect(self.send_message)

        # Send button
        self.send_btn = QPushButton("Send")
        self.send_btn.clicked.connect(self.send_message)

        # Add widgets to input layout
        input_layout.addWidget(self.upload_btn)
        input_layout.addWidget(self.voice_btn)
        input_layout.addWidget(self.search_memory_btn)
        input_layout.addWidget(self.clear_memory_btn)
        input_layout.addWidget(self.message_input)
        input_layout.addWidget(self.send_btn)

        # Status bar
        self.status_bar = QLabel("Ready")
        self.status_bar.setAlignment(Qt.AlignmentFlag.AlignRight)

        # Add all components to main layout
        layout.addWidget(self.chat_area)
        layout.addLayout(input_layout)
        layout.addWidget(self.status_bar)

        # Welcome message
        self.add_message("Welcome to StarBuddy! I'm your personal AI assistant.", is_user=False)

    def on_search_memory(self):
        if not self.memory_manager.is_enabled():
            QMessageBox.warning(self, "Memory Disabled", "Long-term memory is not enabled.", QMessageBox.StandardButton.Ok)
            return
        query, ok = self.get_text_dialog("Search Memory", "Enter your search query:")
        if ok and query.strip():
            results = self.memory_manager.query_memory(query.strip(), n_results=5)
            if results:
                self.show_memory_results_dialog(results)
            else:
                QMessageBox.information(self, "No Results", "No memory results found.")

    # Drag-and-drop image support
    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            for url in event.mimeData().urls():
                if url.isLocalFile() and os.path.splitext(url.toLocalFile())[1].lower() in ['.png', '.jpg', '.jpeg', '.bmp', '.gif']:
                    event.acceptProposedAction()
                    return
        event.ignore()

    def dropEvent(self, event):
        if event.mimeData().hasUrls():
            for url in event.mimeData().urls():
                if url.isLocalFile() and os.path.splitext(url.toLocalFile())[1].lower() in ['.png', '.jpg', '.jpeg', '.bmp', '.gif']:
                    self.handle_image_file(url.toLocalFile())
                    event.acceptProposedAction()
                    return
        event.ignore()

    def on_clear_memory(self):
        if not self.memory_manager.is_enabled():
            QMessageBox.warning(self, "Memory Disabled", "Long-term memory is not enabled.", QMessageBox.StandardButton.Ok)
            return
        confirm = QMessageBox.question(self, "Clear Memory", "Are you sure you want to clear all long-term memory?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if confirm == QMessageBox.StandardButton.Yes:
            success = self.memory_manager.clear_memory()
            if success:
                QMessageBox.information(self, "Memory Cleared", "Long-term memory has been cleared.", QMessageBox.StandardButton.Ok)
            else:
                QMessageBox.warning(self, "Error", "Failed to clear memory.", QMessageBox.StandardButton.Ok)

    def get_text_dialog(self, title, label):
        from PyQt6.QtWidgets import QInputDialog
        text, ok = QInputDialog.getText(self, title, label)
        return text, ok

    def show_memory_results_dialog(self, results):
        from PyQt6.QtWidgets import QDialog, QVBoxLayout, QTextEdit, QPushButton
        dlg = QDialog(self)
        dlg.setWindowTitle("Memory Search Results")
        layout = QVBoxLayout(dlg)
        text_edit = QTextEdit()
        text_edit.setReadOnly(True)
        text = "\n\n---\n\n".join(results)
        text_edit.setText(text)
        layout.addWidget(text_edit)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(dlg.accept)
        layout.addWidget(close_btn)
        dlg.setLayout(layout)
        dlg.resize(600, 400)
        dlg.exec()

        
    def update_settings(self, model, system_prompt):
        """Update settings with new values"""
        self.current_model = model
        self.system_prompt = system_prompt
        
        if model:
            self.status_bar.setText(f"Using model: {model}")
        else:
            self.status_bar.setText("No model selected")
            
    def add_message(self, message, is_user=True, image_path=None):
        """Add a new message bubble to the chat, with correct avatar/name and TTS button for bot messages. Optionally show an image."""
        # Load user/bot names and avatars from config
        config = load_config()
        user_name = config.get("user_name", "You")
        bot_name = config.get("bot_name", "StarBuddy")
        user_avatar = config.get("user_avatar", "")
        bot_avatar = config.get("bot_avatar", "")
        name = user_name if is_user else bot_name
        avatar = user_avatar if is_user else bot_avatar
        bubble = MessageBubble(message, is_user, name=name, avatar_path=avatar, image_path=image_path)
        # Add TTS play button for bot messages
        if not is_user:
            play_btn = QPushButton()
            play_btn.setIcon(QIcon.fromTheme("media-playback-start"))
            play_btn.setToolTip("Read aloud")
            play_btn.setFixedSize(32, 32)
            play_btn.setStyleSheet("margin-left: 8px; margin-right: 8px;")
            def speak_msg():
                if not hasattr(self, 'voice_output'):
                    self.voice_output = VoiceOutput()
                self.voice_output.speak(message)
            play_btn.clicked.connect(speak_msg)
            layout = bubble.layout() if hasattr(bubble, 'layout') else None
            if layout:
                layout.addWidget(play_btn)
        self.chat_layout.addWidget(bubble)
        self.chat_container.adjustSize()
        # Add to history
        self.chat_history.append({
            "role": "user" if is_user else "assistant",
            "content": message,
            "timestamp": datetime.datetime.now().isoformat()
        })
        # Save to memory if enabled and this is an assistant response
        if not is_user and self.memory_manager.is_enabled():
            try:
                self.memory_manager.add_to_memory(self.chat_history)
            except Exception as e:
                self.on_memory_error(str(e))
        QApplication.processEvents()
        # Auto-scroll to bottom
        self.chat_area.verticalScrollBar().setValue(self.chat_area.verticalScrollBar().maximum())

    def on_voice_input(self):
        """Handle voice input: record, transcribe, and insert into message input."""
        try:
            if not hasattr(self, 'voice_input'):
                self.voice_input = VoiceInput()
            self.status_bar.setText("Listening...")
            def do_transcribe():
                try:
                    text = self.voice_input.listen_and_transcribe()
                    if text:
                        self.voice_input_complete.emit(text, "Voice input complete.")
                    else:
                        self.voice_input_complete.emit("", "Could not recognize speech.")
                except Exception as e:
                    self.voice_input_complete.emit("", f"Voice input error: {e}")
            threading.Thread(target=do_transcribe, daemon=True).start()
        except RuntimeError as e:
            QMessageBox.warning(self, "Vosk Model Missing", f"{e}\n\nDownload a Vosk model and extract it to StarBuddy/models/.", QMessageBox.StandardButton.Ok)
            self.status_bar.setText("Vosk model not found.")

    def _set_voice_input_text(self, text, status_msg):
        self.message_input.setText(text)
        self.status_bar.setText(status_msg)

    def send_message(self):
        """Send a user message"""
        message = self.message_input.text().strip()
        if not message:
            return
            
        # Check if model is selected
        if not self.current_model:
            QMessageBox.warning(
                self,
                "No Model Selected",
                "Please select a model in the Settings tab before chatting.",
                QMessageBox.StandardButton.Ok
            )
            return
            
        # Add user message to chat
        self.add_message(message, is_user=True)
        self.message_input.clear()
        
        # Set status
        self.status_bar.setText("Getting response...")
        
        # Start thread to get response
        self.chat_thread = ChatThread(
            self.ollama_api,
            message,
            self.current_model,
            self.system_prompt
        )
        self.chat_thread.response_received.connect(self.on_response_received)
        self.chat_thread.error_occurred.connect(self.on_thread_error)
        self.chat_thread.start()

    def on_thread_error(self, error_msg):
        # Show vision API errors in chat and status bar
        self.add_message(f"[Vision API error]: {error_msg}", is_user=False)
        self.status_bar.setText(f"Vision API error: {error_msg}")
        
    def on_response_received(self, response):
        """Handle the complete response from the API"""
        filtered_response = response
        if not self.show_thinking:
            import re
            filtered_response = re.sub(r'<think>[\s\S]*?<\/think>', '', response, flags=re.IGNORECASE)
            filtered_response = filtered_response.strip()
        self.add_message(filtered_response, is_user=False)
        self.status_bar.setText(f"Using model: {self.current_model}")
        
    def on_response_chunk(self, chunk):
        """Handle streaming response chunks (not fully implemented yet)"""
        pass  # For future streaming implementation
        
    def on_thread_error(self, error_msg):
        """Handle errors in the chat thread"""
        QMessageBox.critical(
            self,
            "Error",
            f"Error getting response: {error_msg}",
            QMessageBox.StandardButton.Ok
        )
        self.status_bar.setText(f"Error: {error_msg}")
        
    def on_api_error(self, error_msg):
        """Handle API errors"""
        QMessageBox.critical(
            self,
            "API Error",
            f"Ollama API error: {error_msg}",
            QMessageBox.StandardButton.Ok
        )
        self.status_bar.setText(f"API Error: {error_msg}")
        
    def on_upload_file(self):
        """Handle file uploads"""
        options = QFileDialog.Option.ReadOnly
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Upload File",
            "",
            "All Files (*);;Text Files (*.txt);;PDF Files (*.pdf);;JSON Files (*.json);;Markdown Files (*.md);;Images (*.png *.jpg *.jpeg)",
            options=options
        )
        
        if file_path:
            file_name = os.path.basename(file_path)
            file_ext = os.path.splitext(file_name)[1].lower()
            # Handle different file types
            if file_ext in ['.txt', '.md']:
                self.handle_text_file(file_path, file_ext)
            elif file_ext == '.json':
                self.handle_json_file(file_path)
            elif file_ext == '.pdf':
                self.handle_pdf_file(file_path)
            elif file_ext in ['.png', '.jpg', '.jpeg']:
                self.handle_image_file(file_path)
            else:
                self.status_bar.setText(f"Unsupported file type: {file_ext}")
                
    def handle_text_file(self, file_path, file_ext='.txt'):
        """Handle text and markdown file uploads"""
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()
            file_name = os.path.basename(file_path)
            preview = content[:500]
            truncated = len(content) > 500
            if file_ext == '.md':
                preview_msg = f"Uploaded Markdown file: {file_name}\nPreview:\n{preview}"
                prompt = f"The user has uploaded a Markdown file named '{file_name}'. Preview:\n\n{preview}"
            else:
                preview_msg = f"Uploaded text file: {file_name}\nPreview:\n{preview}"
                prompt = f"The user has uploaded a text file named '{file_name}'. Preview:\n\n{preview}"
            if truncated:
                preview_msg += "\n... (truncated)"
                prompt += "\n... (truncated)"
            self.add_message(preview_msg, is_user=True)
            # Send to API
            self.status_bar.setText("Processing file...")
            self.chat_thread = ChatThread(
                self.ollama_api,
                prompt,
                self.current_model,
                self.system_prompt
            )
            self.chat_thread.response_received.connect(self.on_response_received)
            self.chat_thread.error_occurred.connect(self.on_thread_error)
            self.chat_thread.start()
        except Exception as e:
            self.status_bar.setText(f"Error reading file: {str(e)}")
            
    def handle_pdf_file(self, file_path):
        """Handle PDF file uploads"""
        try:
            from PyPDF2 import PdfReader
            reader = PdfReader(file_path)
            content = ""
            for page in reader.pages:
                text = page.extract_text()
                if text:
                    content += text + "\n"
            file_name = os.path.basename(file_path)
            preview = content[:500]
            truncated = len(content) > 500
            preview_msg = f"Uploaded PDF file: {file_name}\nPreview:\n{preview}"
            if truncated:
                preview_msg += "\n... (truncated)"
            self.add_message(preview_msg, is_user=True)
            # Create a system message with file preview
            prompt = f"The user has uploaded a PDF file named '{file_name}'. Preview:\n\n{preview}"
            if truncated:
                prompt += "\n... (truncated)"
            # Send to API
            self.status_bar.setText("Processing file...")
            self.chat_thread = ChatThread(
                self.ollama_api,
                prompt,
                self.current_model,
                self.system_prompt
            )
            self.chat_thread.response_received.connect(self.on_response_received)
            self.chat_thread.error_occurred.connect(self.on_thread_error)
            self.chat_thread.start()
        except Exception as e:
            self.status_bar.setText(f"Error reading PDF: {str(e)}")
            
    def handle_image_file(self, file_path):
        """Handle image file uploads for vision models"""
        import base64
        file_name = os.path.basename(file_path)
        # Check if current model is a vision model (simple heuristic: contains 'vision' or 'llava')
        vision_keywords = ['vision', 'llava', 'image', 'clip', 'vl']
        model_lower = self.current_model.lower() if self.current_model else ''
        is_vision = any(k in model_lower for k in vision_keywords)
        if not is_vision:
            self.add_message(f"Uploaded image file: {file_name}", is_user=True)
            self.status_bar.setText("The selected model does not support image analysis. Please select a vision model (e.g., 'llava', 'vision', etc.) in Settings.")
            return
        # Get user prompt for the image
        from PyQt6.QtWidgets import QInputDialog
        prompt, ok = QInputDialog.getText(
            self,
            'Image Analysis',
            'What do you want to know about this image?',
            text='Please describe and analyze this image'
        )
        if not ok or not prompt.strip():
            self.status_bar.setText('Image analysis canceled')
            return

        self.add_message(f"Uploaded image: {file_name}\nQuestion: {prompt}", is_user=True, image_path=file_path)
        # Read and encode image
        try:
            with open(file_path, 'rb') as img_file:
                img_bytes = img_file.read()
            img_b64 = base64.b64encode(img_bytes).decode('utf-8')
            # Compose user-friendly prompt for vision model
            # prompt is already a string from the dialog above, do not convert to tuple
            # (fix: remove comma)
            # prompt = prompt
            # Use a custom ChatThread to support the images param
            class ImageChatThread(QThread):
                response_received = pyqtSignal(str)
                error_occurred = pyqtSignal(str)
                def __init__(self, api, prompt, model, system_prompt, images):
                    super().__init__()
                    self.api = api
                    self.prompt = prompt
                    self.model = model
                    self.system_prompt = system_prompt
                    self.images = images
                def run(self):
                    try:
                        response = self.api.generate_response(
                            prompt=self.prompt,
                            model=self.model,
                            system_prompt=self.system_prompt,
                            stream=False,  # Disable streaming for vision requests
                            images=self.images
                        )
                        if response:
                            self.response_received.emit(response)
                        else:
                            self.error_occurred.emit('No response received from Ollama vision API.')
                    except Exception as e:
                        self.error_occurred.emit(f'Ollama vision error: {str(e)}')
            # For vision/image requests, prepend the prompt with the image placeholder if model is vision-capable
            vision_keywords = ['llava', 'vision', 'vl', 'qwen']
            model_lower = self.current_model.lower() if self.current_model else ''
            if any(k in model_lower for k in vision_keywords):
                vision_prompt = f"<|image|>\n{prompt}"
            else:
                vision_prompt = prompt

            self.chat_thread = ImageChatThread(
                self.ollama_api,
                vision_prompt,
                self.current_model,
                self.system_prompt,
                [img_b64]
            )
            self.chat_thread.response_received.connect(self.on_response_received)
            self.chat_thread.error_occurred.connect(self.on_thread_error)
            self.chat_thread.start()
        except Exception as e:
            self.status_bar.setText(f"Error reading image: {str(e)}")

    def handle_json_file(self, file_path):
        """Handle JSON file uploads"""
        import json
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                data = json.load(file)
            import pprint
            pretty = pprint.pformat(data, width=80, compact=False)
            preview = pretty[:500]
            truncated = len(pretty) > 500
            file_name = os.path.basename(file_path)
            preview_msg = f"Uploaded JSON file: {file_name}\nPreview:\n{preview}"
            prompt = f"The user has uploaded a JSON file named '{file_name}'. Preview:\n\n{preview}"
            if truncated:
                preview_msg += "\n... (truncated)"
                prompt += "\n... (truncated)"
            self.add_message(preview_msg, is_user=True)
            # Send to API
            self.status_bar.setText("Processing file...")
            self.chat_thread = ChatThread(
                self.ollama_api,
                prompt,
                self.current_model,
                self.system_prompt
            )
            self.chat_thread.response_received.connect(self.on_response_received)
            self.chat_thread.error_occurred.connect(self.on_thread_error)
            self.chat_thread.start()
        except Exception as e:
            self.status_bar.setText(f"Error reading JSON: {str(e)}")
