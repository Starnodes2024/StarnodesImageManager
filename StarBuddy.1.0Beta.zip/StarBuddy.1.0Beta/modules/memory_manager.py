#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import datetime
from PyQt6.QtCore import QObject, pyqtSignal

try:
    import chromadb
    from langchain_community.embeddings import HuggingFaceEmbeddings
    MEMORY_AVAILABLE = True
except ImportError:
    MEMORY_AVAILABLE = False


class MemoryManager(QObject):
    """Class to handle long-term memory storage and retrieval"""
    
    memory_error = pyqtSignal(str)
    memory_updated = pyqtSignal()
    
    def __init__(self, storage_dir="./memory", enabled=False):
        super().__init__()
        self.storage_dir = storage_dir
        self.enabled = enabled and MEMORY_AVAILABLE
        self.client = None
        self.collection = None
        
        # Initialize if enabled
        if self.enabled:
            self.initialize_memory()
            
    def initialize_memory(self):
        """Initialize the memory database"""
        if not MEMORY_AVAILABLE:
            self.memory_error.emit("Required libraries for memory not installed")
            self.enabled = False
            return
            
        try:
            # Create storage directory if it doesn't exist
            os.makedirs(self.storage_dir, exist_ok=True)
            
            # Initialize ChromaDB client
            self.client = chromadb.PersistentClient(path=self.storage_dir)
            
            # Get or create collection
            try:
                self.collection = self.client.get_collection("chat_memory")
            except ValueError:
                # Collection doesn't exist, create it
                self.collection = self.client.create_collection(
                    name="chat_memory",
                    metadata={"description": "StarBuddy chat memory"}
                )
                
            return True
        except Exception as e:
            self.memory_error.emit(f"Error initializing memory: {str(e)}")
            self.enabled = False
            return False
            
    def is_enabled(self):
        """Check if memory is enabled and available"""
        return self.enabled and MEMORY_AVAILABLE
        
    def set_enabled(self, enabled):
        """Enable or disable memory"""
        if enabled and not MEMORY_AVAILABLE:
            self.memory_error.emit("Required libraries for memory not installed")
            return False
            
        self.enabled = enabled
        
        if enabled and not self.client:
            return self.initialize_memory()
        return True
        
    def set_storage_dir(self, storage_dir):
        """Set the storage directory"""
        if self.storage_dir != storage_dir:
            self.storage_dir = storage_dir
            if self.enabled:
                # Re-initialize with new directory
                return self.initialize_memory()
        return True
        
    def add_to_memory(self, chat_history):
        """Add a conversation to memory"""
        if not self.is_enabled() or not self.collection:
            return False
            
        try:
            # Convert chat history to a single document
            conversation = "\n".join([
                f"{msg['role']}: {msg['content']}" 
                for msg in chat_history
            ])
            
            # Create metadata
            metadata = {
                "timestamp": datetime.datetime.now().isoformat(),
                "messages": len(chat_history)
            }
            
            # Generate a document ID
            doc_id = f"chat_{metadata['timestamp']}"
            
            # Add to collection
            self.collection.add(
                documents=[conversation],
                metadatas=[metadata],
                ids=[doc_id]
            )
            
            self.memory_updated.emit()
            return True
        except Exception as e:
            self.memory_error.emit(f"Error adding to memory: {str(e)}")
            return False
            
    def query_memory(self, query, n_results=5):
        """Query the memory for relevant conversations"""
        if not self.is_enabled() or not self.collection:
            return []
            
        try:
            results = self.collection.query(
                query_texts=[query],
                n_results=n_results
            )
            
            if results and 'documents' in results and results['documents']:
                return results['documents'][0]  # First query results
            return []
        except Exception as e:
            self.memory_error.emit(f"Error querying memory: {str(e)}")
            return []
            
    def clear_memory(self):
        """Clear all memory"""
        if not self.is_enabled() or not self.collection:
            return False
            
        try:
            # Delete collection and recreate
            self.client.delete_collection("chat_memory")
            self.collection = self.client.create_collection(
                name="chat_memory",
                metadata={"description": "StarBuddy chat memory"}
            )
            
            self.memory_updated.emit()
            return True
        except Exception as e:
            self.memory_error.emit(f"Error clearing memory: {str(e)}")
            return False
