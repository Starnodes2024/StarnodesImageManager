import os
import sys

def resource_path(relative_path):
    """Get absolute path to resource, always from real folders next to exe or script."""
    if getattr(sys, 'frozen', False):
        # Running as bundled exe
        base_path = os.path.dirname(sys.executable)
    else:
        # One level up from modules/utils.py (project root)
        base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_path, relative_path)

def ensure_model_extracted(model_folder_name):
    """
    Always return the path to the model in the 'models' subfolder next to the exe or script.
    """
    if getattr(sys, 'frozen', False):
        exe_dir = os.path.dirname(sys.executable)
        return os.path.join(exe_dir, 'models', model_folder_name)
    else:
        return os.path.join(os.path.dirname(__file__), '..', 'models', model_folder_name)
