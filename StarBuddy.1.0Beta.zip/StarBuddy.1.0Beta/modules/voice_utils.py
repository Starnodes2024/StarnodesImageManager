import os
import queue
import threading
import tempfile
import wave

import pyttsx3
import speech_recognition as sr
from vosk import Model, KaldiRecognizer

# Import the extraction helper from the main app
from modules.utils import ensure_model_extracted

class VoiceInput:
    """Handles offline speech-to-text using Vosk and SpeechRecognition."""
    def __init__(self, model_path=None, lang="en-US"):
        import json
        config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "config.json"))
        selected_model = None
        if os.path.isfile(config_path):
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    config = json.load(f)
                selected_model = config.get("voice_model")
            except Exception:
                selected_model = None
        # Always use the extracted model path utility for PyInstaller compatibility
        model_folder_name = selected_model or "vosk-model-small-en-us-0.15"
        model_path = ensure_model_extracted(model_folder_name)
        self.model_path = os.path.abspath(model_path)
        print("Please wait, voice model is loading...")
        if not os.path.isdir(self.model_path):
            raise RuntimeError(f"Vosk model not found at {self.model_path}. Please download and extract it.")
        self.model = Model(self.model_path)
        self.recognizer = sr.Recognizer()
        self.lang = lang

    def listen_and_transcribe(self, timeout=5):
        """Listen from the default microphone and transcribe speech to text. Includes debug logging."""
        import tempfile
        import sys
        with sr.Microphone() as source:

            audio = self.recognizer.listen(source, timeout=timeout)
            data = audio.get_wav_data()

        from pydub import AudioSegment
        import io
        rec = KaldiRecognizer(self.model, 16000)
        tmpfile = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
        tmpfile_name = tmpfile.name
        tmpfile.close()
        # Preprocess audio: normalize and reduce noise
        audio_segment = AudioSegment.from_file(io.BytesIO(data), format="wav")
        # Normalize loudness
        audio_segment = audio_segment.apply_gain(-audio_segment.max_dBFS)
        # Simple noise gate: zero out audio below a threshold
        import numpy as np
        samples = np.array(audio_segment.get_array_of_samples())
        threshold = int(0.02 * np.iinfo(samples.dtype).max)  # 2% of max amplitude
        samples[np.abs(samples) < threshold] = 0
        audio_segment = audio_segment._spawn(samples.tobytes())
        # Resample to 16kHz mono
        if audio_segment.frame_rate != 16000 or audio_segment.channels != 1:
            audio_segment = audio_segment.set_frame_rate(16000).set_channels(1)
        resampled_data = io.BytesIO()
        audio_segment.export(resampled_data, format="wav")
        resampled_data.seek(0)
        resampled_bytes = resampled_data.read()
        # Save the resampled audio to file for Vosk
        with open(tmpfile_name, "wb") as wf:
            wf.write(resampled_bytes)
        # Save for debugging
        with open("debug_last_input.wav", "wb") as wf_debug:
            wf_debug.write(resampled_bytes)
        with wave.open(tmpfile_name, "rb") as wf_read:
            while True:
                buf = wf_read.readframes(4000)
                if len(buf) == 0:
                    break
                if rec.AcceptWaveform(buf):
                    pass
            result = rec.FinalResult()

        os.remove(tmpfile_name)
        import json
        try:
            text = json.loads(result)["text"]
            print(f"Recognized text: '{text}'")
        except Exception as e:

            text = ""
        return text.strip()


class VoiceOutput:
    """Handles offline text-to-speech using pyttsx3."""
    def __init__(self, rate=180, volume=1.0, voice=None):
        self.engine = pyttsx3.init()
        self.engine.setProperty('rate', rate)
        self.engine.setProperty('volume', volume)
        if voice:
            self.engine.setProperty('voice', voice)
        self._queue = queue.Queue()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self):
        while True:
            text = self._queue.get()
            if text is None:
                break
            self.engine.say(text)
            self.engine.runAndWait()

    def speak(self, text):
        self._queue.put(text)

    def stop(self):
        self._queue.put(None)
        self.engine.stop()
