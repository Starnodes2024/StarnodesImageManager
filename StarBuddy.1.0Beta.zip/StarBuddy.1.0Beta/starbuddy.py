#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
os.environ["VOSK_LOG_LEVEL"] = "-1"
import sys
# Ensure the app directory is always on sys.path
if getattr(sys, 'frozen', False):
    sys.path.insert(0, os.path.dirname(sys.executable))
else:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import json
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                            QHBoxLayout, QTextEdit, QLineEdit, QPushButton, 
                            QComboBox, QLabel, QFileDialog, QTabWidget,
                            QScrollArea, QSplitter, QFrame, QMessageBox)
from PyQt6.QtGui import QFont, QIcon, QPixmap, QTextCursor, QAction
from PyQt6.QtCore import Qt, QSize, QThread, pyqtSignal, QSettings

from modules.ollama_api import OllamaAPI
from modules.chat_widget import ChatWidget
from modules.settings_widget import SettingsWidget
from modules.memory_manager import MemoryManager
from modules.utils import resource_path, ensure_model_extracted

# Theme loader utility
import shutil



CONFIG_PATH = resource_path('config.json')

def load_theme_stylesheet():
    theme_name = 'light'
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = json.load(f)
                theme_name = config.get('theme', 'light')
        except Exception:
            pass
    theme_file = resource_path(os.path.join('designs', f'{theme_name}.qss'))
    if os.path.exists(theme_file):
        with open(theme_file, 'r', encoding='utf-8') as f:
            return f.read()
    return ''

class StarBuddy(QMainWindow):
    def __init__(self):
        super().__init__()
        
        # Initialize application settings
        self.settings = QSettings("StarBuddy 1.0", "StarBuddy 1.0")
        
        # Initialize API client
        self.ollama_api = OllamaAPI()
        
        # Initialize memory manager (enabled by default)
        import json
        config_path = resource_path('config.json')
        default_memory_enabled = True
        default_memory_dir = './memory'
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    default_memory_enabled = config.get('enable_memory', True)
                    default_memory_dir = config.get('memory_location', './memory')
            except Exception:
                pass
        self.memory_manager = MemoryManager(storage_dir=default_memory_dir, enabled=default_memory_enabled)

        
        # UI setup
        self.init_ui()
        
        # Load saved settings
        self.load_settings()
        
    def init_ui(self):
        """Initialize the user interface"""
        self.setWindowTitle("StarBuddy 1.0")
        self.setMinimumSize(400, 600)
        
        # Create central widget and main layout
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.main_layout = QVBoxLayout(self.central_widget)
        
        # Create tab widget
        self.tab_widget = QTabWidget()
        
        # Create chat tab
        self.chat_widget = ChatWidget(self.ollama_api, self.memory_manager)
        self.tab_widget.addTab(self.chat_widget, "Chat")
        
        # Create settings tab
        self.settings_widget = SettingsWidget(self.ollama_api)
        self.tab_widget.addTab(self.settings_widget, "Settings")
        
        # Add tab widget to main layout
        self.main_layout.addWidget(self.tab_widget)
        
        # Connect signals
        self.settings_widget.settings_updated.connect(self.on_settings_updated)
        
        # Show the window
        self.show()
        
    def load_settings(self):
        """Load saved settings from QSettings"""
        # Load api endpoint
        api_endpoint = self.settings.value("api_endpoint", "http://localhost:11434")
        self.settings_widget.set_api_endpoint(api_endpoint)
        
        # Load selected model
        selected_model = self.settings.value("selected_model", "")
        self.settings_widget.set_model(selected_model)
        
        # Load system prompt
        system_prompt = self.settings.value("system_prompt", "You are a helpful AI assistant.")
        self.settings_widget.set_system_prompt(system_prompt)
        
    def on_settings_updated(self):
        """Handle settings updates"""
        # Save settings
        self.settings.setValue("api_endpoint", self.settings_widget.get_api_endpoint())
        self.settings.setValue("selected_model", self.settings_widget.get_model())
        self.settings.setValue("system_prompt", self.settings_widget.get_system_prompt())
        
        # Update API client
        self.ollama_api.set_endpoint(self.settings_widget.get_api_endpoint())
        
        # Sync memory settings
        memory_enabled = self.settings_widget.is_memory_enabled()
        memory_location = self.settings_widget.get_memory_location()
        self.memory_manager.set_enabled(memory_enabled)
        self.memory_manager.set_storage_dir(memory_location)
        
        # Update chat widget
        self.chat_widget.update_settings(
            model=self.settings_widget.get_model(),
            system_prompt=self.settings_widget.get_system_prompt()
        )
        # Reload theme if changed
        stylesheet = load_theme_stylesheet()
        self.parent().setStyleSheet(stylesheet) if self.parent() else self.setStyleSheet(stylesheet)
        
    def closeEvent(self, event):
        """Handle application close event"""
        # Save settings
        self.on_settings_updated()
        event.accept()

def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')  # Use Fusion style for a modern look
    
    # Set application font
    font = QFont("Segoe UI", 11)  # Increased font size
    app.setFont(font)
    
    # Apply the selected theme stylesheet
    app.setStyleSheet(load_theme_stylesheet())
    
    # Create and show the main window
    window = StarBuddy()
    
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
