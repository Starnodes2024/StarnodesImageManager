#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
import json
from PyQt6.QtCore import QObject, pyqtSignal


class OllamaAPI(QObject):
    """Class to handle communication with the Ollama API"""
    
    error_occurred = pyqtSignal(str)
    models_updated = pyqtSignal(list)
    response_chunk = pyqtSignal(str)
    
    def __init__(self, endpoint="http://localhost:11434"):
        super().__init__()
        self.endpoint = endpoint
        self.current_model = None
        
    def set_endpoint(self, endpoint):
        """Set the API endpoint URL"""
        self.endpoint = endpoint
        
    def get_models(self):
        """Retrieve available models from Ollama"""
        try:
            url = f"{self.endpoint}/api/tags"
            response = requests.get(url)
            
            if response.status_code == 200:
                data = response.json()
                models = [model.get('name') for model in data.get('models', [])]
                self.models_updated.emit(models)
                return models
            else:
                error_msg = f"Failed to get models: {response.status_code} - {response.text}"
                self.error_occurred.emit(error_msg)
                return []
                
        except Exception as e:
            error_msg = f"Error connecting to Ollama: {str(e)}"
            self.error_occurred.emit(error_msg)
            return []
            
    def generate_response(self, prompt, model=None, system_prompt=None, stream=True, images=None):
        """Generate a response from the Ollama model. If images (list of base64 strings) is provided, send to vision models."""
        if not model:
            if not self.current_model:
                self.error_occurred.emit("No model selected")
                return ""
            model = self.current_model
        try:
            url = f"{self.endpoint}/api/generate"
            payload = {
                "model": model,
                "prompt": prompt,
                "stream": stream
            }
            if system_prompt:
                payload["system"] = system_prompt
            if images:
                payload["images"] = images  # list of base64-encoded images
            import requests, json
            response = requests.post(url, json=payload, stream=stream)

            if stream:
                full_response = ""
                for line in response.iter_lines():
                    if line:
                        line_data = json.loads(line.decode('utf-8'))
                        chunk = line_data.get('response', '')
                        full_response += chunk
                        self.response_chunk.emit(chunk)
                        if line_data.get('done', False):
                            break
                if not full_response:
                    error_msg = f"Ollama vision: Empty response (streaming). Status: {response.status_code}. Body: {response.text[:500]}"
                    self.error_occurred.emit(error_msg)
                return full_response
            else:
                if response.status_code == 200:
                    try:
                        data = response.json()
                        result = data.get('response', '')
                        if not result:
                            error_msg = f"Ollama vision: API returned 200 but no response. Body: {response.text[:500]}"
                            self.error_occurred.emit(error_msg)
                        return result
                    except Exception as parse_e:
                        error_msg = f"Ollama vision: JSON parse error: {str(parse_e)}. Body: {response.text[:500]}"
                        self.error_occurred.emit(error_msg)
                        return ""
                else:
                    error_msg = f"Ollama vision: API error: {response.status_code} - {response.text[:500]}"
                    self.error_occurred.emit(error_msg)
                    return ""
        except Exception as e:
            error_msg = f"Error generating response: {str(e)}"
            self.error_occurred.emit(error_msg)
            return ""
    
    def upload_file(self, file_path, model=None):
        """
        Not all models support file uploads directly.
        This is a placeholder for potential future implementation.
        For now, we'll handle file uploads by reading the content and sending it as part of the prompt.
        """
        self.error_occurred.emit("File upload to Ollama API not currently supported")
        return False
