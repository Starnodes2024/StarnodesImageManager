#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                           QLineEdit, QPushButton, QComboBox, QTextEdit,
                           QGroupBox, QFormLayout, QCheckBox, QMessageBox)
from PyQt6.QtCore import Qt, pyqtSignal, QMetaObject
import threading
import time
from .config_manager import load_config, save_config
import os
from PyQt6.QtWidgets import QLineEdit, QPushButton, QFileDialog, QLabel, QHBoxLayout
from PyQt6.QtGui import QPixmap

class SettingsWidget(QWidget):
    """Widget for application settings"""
    
    settings_updated = pyqtSignal()
    
    def __init__(self, ollama_api, parent=None):
        super().__init__(parent)
        self.ollama_api = ollama_api
        self.models = []
        # Load config and store
        self.config = load_config()
        self.init_ui()
        
        # Connect signals
        self.ollama_api.models_updated.connect(self.update_model_list)
        self.ollama_api.error_occurred.connect(self.on_api_error)
        
        # Load models
        self.load_models()
        
    def init_ui(self):
        """Initialize the settings widget UI"""
        from PyQt6.QtWidgets import QTabWidget, QWidget, QComboBox, QLabel
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(15)

        # --- Voice Model Selection ---
        voice_model_hbox = QHBoxLayout()
        voice_model_label = QLabel("Voice Model:")
        self.voice_model_dropdown = QComboBox()
        # Scan models directory for vosk models
        models_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "models"))
        vosk_models = [d for d in os.listdir(models_dir) if d.startswith("vosk-model") and os.path.isdir(os.path.join(models_dir, d))]
        self.voice_model_dropdown.addItems(vosk_models)
        # Set current from config if present
        current_voice_model = self.config.get("voice_model", "")
        if current_voice_model and current_voice_model in vosk_models:
            self.voice_model_dropdown.setCurrentText(current_voice_model)
        voice_model_hbox.addWidget(voice_model_label)
        voice_model_hbox.addWidget(self.voice_model_dropdown)
        main_layout.addLayout(voice_model_hbox)

        tabs = QTabWidget()
        # --- Profiles Tab ---
        profiles_tab = QWidget()
        profiles_layout = QVBoxLayout(profiles_tab)
        profiles_layout.setSpacing(15)
        profiles_layout.setContentsMargins(15, 15, 15, 15)
        # User profile
        user_hbox = QHBoxLayout()
        self.user_avatar_label = QLabel()
        self.user_avatar_label.setFixedSize(100, 100)
        self.user_avatar_label.setScaledContents(True)
        self.user_avatar_path = self.config.get("user_avatar", "")
        if self.user_avatar_path and os.path.exists(self.user_avatar_path):
            self.user_avatar_label.setPixmap(QPixmap(self.user_avatar_path).scaled(100, 100))
        user_avatar_btn = QPushButton("Upload Avatar")
        def upload_user_avatar():
            file, _ = QFileDialog.getOpenFileName(self, "Select Avatar", "", "Images (*.png *.jpg *.jpeg)")
            if file:
                # Create a 100x100 thumbnail and save to the main directory
                from PIL import Image
                import os
                img = Image.open(file)
                img = img.convert('RGBA') if img.mode != 'RGBA' else img
                img.thumbnail((100, 100), Image.LANCZOS)
                base_name = os.path.basename(file)
                thumb_name = f"user_avatar_{base_name}"
                main_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
                thumb_path = os.path.join(main_dir, thumb_name)
                img.save(thumb_path, format='PNG')
                self.user_avatar_path = thumb_path
                self.user_avatar_label.setPixmap(QPixmap(thumb_path).scaled(100, 100))
        user_avatar_btn.clicked.connect(upload_user_avatar)
        user_info_vbox = QVBoxLayout()
        self.user_name_edit = QLineEdit(self.config.get("user_name", "User"))
        self.user_name_edit.setMinimumWidth(200)
        user_info_vbox.addWidget(QLabel("Your Name:"))
        user_info_vbox.addWidget(self.user_name_edit)
        user_info_vbox.addWidget(user_avatar_btn)
        user_hbox.addWidget(self.user_avatar_label)
        user_hbox.addSpacing(15)
        user_hbox.addLayout(user_info_vbox)
        profiles_layout.addLayout(user_hbox)
        # Bot profile
        bot_hbox = QHBoxLayout()
        self.bot_avatar_label = QLabel()
        self.bot_avatar_label.setFixedSize(100, 100)
        self.bot_avatar_label.setScaledContents(True)
        self.bot_avatar_path = self.config.get("bot_avatar", "")
        if self.bot_avatar_path and os.path.exists(self.bot_avatar_path):
            self.bot_avatar_label.setPixmap(QPixmap(self.bot_avatar_path).scaled(100, 100))
        bot_avatar_btn = QPushButton("Upload Avatar")
        def upload_bot_avatar():
            file, _ = QFileDialog.getOpenFileName(self, "Select Avatar", "", "Images (*.png *.jpg *.jpeg)")
            if file:
                # Create a 100x100 thumbnail and save to the main directory
                from PIL import Image
                import os
                img = Image.open(file)
                img = img.convert('RGBA') if img.mode != 'RGBA' else img
                img.thumbnail((100, 100), Image.LANCZOS)
                base_name = os.path.basename(file)
                thumb_name = f"bot_avatar_{base_name}"
                main_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
                thumb_path = os.path.join(main_dir, thumb_name)
                img.save(thumb_path, format='PNG')
                self.bot_avatar_path = thumb_path
                self.bot_avatar_label.setPixmap(QPixmap(thumb_path).scaled(100, 100))
        bot_avatar_btn.clicked.connect(upload_bot_avatar)
        bot_info_vbox = QVBoxLayout()
        self.bot_name_edit = QLineEdit(self.config.get("bot_name", "StarBuddy 1.0"))
        self.bot_name_edit.setMinimumWidth(200)
        bot_info_vbox.addWidget(QLabel("Bot Name:"))
        bot_info_vbox.addWidget(self.bot_name_edit)
        bot_info_vbox.addWidget(bot_avatar_btn)
        bot_hbox.addWidget(self.bot_avatar_label)
        bot_hbox.addSpacing(15)
        bot_hbox.addLayout(bot_info_vbox)
        profiles_layout.addLayout(bot_hbox)
        tabs.addTab(profiles_tab, "Profiles")

        # --- Settings Tab ---
        settings_tab = QWidget()
        layout = QVBoxLayout(settings_tab)
        layout.setSpacing(15)
        # Theme selection
        theme_group = QGroupBox("Theme")
        theme_layout = QFormLayout()
        theme_layout.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)
        theme_layout.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)
        theme_layout.setSpacing(10)
        designs_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "designs")
        theme_files = [f for f in os.listdir(designs_dir) if f.endswith(".qss")]
        theme_names = [os.path.splitext(f)[0] for f in theme_files]
        self.theme_dropdown = QComboBox()
        self.theme_dropdown.addItems(theme_names)
        theme_default = self.config.get("theme", "light")
        if theme_default in theme_names:
            self.theme_dropdown.setCurrentText(theme_default)
        theme_layout.addRow(QLabel("Select Theme:"), self.theme_dropdown)
        theme_group.setLayout(theme_layout)
        layout.addWidget(theme_group)
        # API settings group and others are added here as before...
        # ... (rest of settings UI, API, model, etc.)
        tabs.addTab(settings_tab, "Settings")
        main_layout.addWidget(tabs)
        api_group = QGroupBox("Ollama API Settings")
        api_layout = QFormLayout()
        api_layout.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)
        api_layout.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)
        api_layout.setSpacing(10)  # Add more space between form elements
        
        # Configure endpoint input with better styling
        endpoint_default = self.config.get("api_endpoint", "http://localhost:11434")
        self.api_endpoint = QLineEdit(endpoint_default)
        self.api_endpoint.setMinimumHeight(30)  # Increase height for better clickability
        api_endpoint_label = QLabel("API Endpoint:")
        api_endpoint_label.setStyleSheet("font-weight: bold;")
        api_layout.addRow(api_endpoint_label, self.api_endpoint)
        
        # Configure test button with better styling
        self.test_api_btn = QPushButton("Test Connection")
        self.test_api_btn.setMinimumHeight(30)
        self.test_api_btn.clicked.connect(self.test_api_connection)
        api_layout.addRow("", self.test_api_btn)
        
        api_group.setLayout(api_layout)
        
        # Model settings group
        model_group = QGroupBox("Model Settings")
        model_layout = QFormLayout()
        model_layout.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)
        model_layout.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)
        model_layout.setSpacing(10)  # Add more space between form elements
        
        # Configure model dropdown with better styling
        self.model_dropdown = QComboBox()
        self.model_dropdown.setMinimumHeight(30)  # Increase height for better clickability
        self.model_dropdown.setStyleSheet("""
            QComboBox {
                padding: 5px;
                font-size: 12px;
            }
        """)
        
        self.refresh_models_btn = QPushButton("Refresh")
        self.refresh_models_btn.setMinimumHeight(30)
        self.refresh_models_btn.clicked.connect(self.load_models)
        
        model_row_layout = QHBoxLayout()
        model_row_layout.addWidget(self.model_dropdown, 3)  # Proportional sizing
        model_row_layout.addWidget(self.refresh_models_btn, 1)  # Proportional sizing
        
        model_label = QLabel("Select Model:")
        model_label.setStyleSheet("font-weight: bold;")
        model_layout.addRow(model_label, model_row_layout)
        
        # Configure system prompt with better styling
        sys_prompt_default = self.config.get("system_prompt", "You are a helpful AI assistant.")
        self.system_prompt = QTextEdit()
        self.system_prompt.setPlaceholderText("Enter a system prompt for the AI...")
        self.system_prompt.setText(sys_prompt_default)
        self.system_prompt.setMinimumHeight(100)
        self.system_prompt.setStyleSheet("""
            QTextEdit {
                font-size: 12px;
                line-height: 1.5;
                padding: 8px;
            }
        """)
        
        system_prompt_label = QLabel("System Prompt:")
        system_prompt_label.setStyleSheet("font-weight: bold;")
        model_layout.addRow(system_prompt_label, self.system_prompt)

        # Add show_thinking checkbox
        show_thinking_default = self.config.get("show_thinking", True)
        self.show_thinking_checkbox = QCheckBox("Show model thinking process (<think>...</think>)")
        self.show_thinking_checkbox.setChecked(show_thinking_default)
        model_layout.addRow("", self.show_thinking_checkbox)

        model_group.setLayout(model_layout)
        
        # Memory settings group
        memory_group = QGroupBox("Memory Settings")
        memory_layout = QFormLayout()
        memory_layout.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)
        memory_layout.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)
        memory_layout.setSpacing(10)  # Add more space between form elements
        
        # Configure memory checkbox with better styling
        self.enable_memory = QCheckBox("Enable Long-Term Memory")
        self.enable_memory.setStyleSheet("""
            QCheckBox {
                font-size: 12px;
                font-weight: bold;
                spacing: 10px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
            }
        """)
        memory_layout.addRow("", self.enable_memory)
        
        # Configure memory location with better styling
        self.memory_location = QLineEdit("./memory")
        self.memory_location.setMinimumHeight(30)  # Increase height for better clickability
        memory_location_label = QLabel("Memory Storage:")
        memory_location_label.setStyleSheet("font-weight: bold;")
        memory_layout.addRow(memory_location_label, self.memory_location)
        
        memory_group.setLayout(memory_layout)
        
        # Save button with better styling
        self.save_btn = QPushButton("Save Settings")
        self.save_btn.setMinimumHeight(40)  # Bigger button
        self.save_btn.setStyleSheet("""
            QPushButton {
                font-size: 14px;
                font-weight: bold;
            }
        """)
        self.save_btn.clicked.connect(self.save_settings)
        
        # Add all components to main layout
        layout.addWidget(api_group)
        layout.addWidget(model_group)
        layout.addWidget(memory_group)
        layout.addWidget(self.save_btn)
        layout.addStretch()
        
    def load_models(self):
        """Load available models from Ollama"""
        self.refresh_models_btn.setEnabled(False)
        self.refresh_models_btn.setText("Loading...")
        
        # Use a thread to avoid UI freezing
        def fetch_models():
            self.ollama_api.set_endpoint(self.api_endpoint.text().strip())
            models = self.ollama_api.get_models()
            
            # Need to use signals to update UI from another thread
            if models:
                self.models = models
                self.update_model_list(models)
            
            # Re-enable button
            self.refresh_models_btn.setEnabled(True)
            self.refresh_models_btn.setText("Refresh")
        
        threading.Thread(target=fetch_models).start()
        
    def update_model_list(self, models):
        """Update the model dropdown with available models"""
        # Try to restore model from config first
        config_model = self.config.get("model")
        self.model_dropdown.clear()
        self.models = models
        for model in models:
            self.model_dropdown.addItem(model)
        # Try to restore previous selection from config
        if config_model and config_model in models:
            index = self.model_dropdown.findText(config_model)
            if index >= 0:
                self.model_dropdown.setCurrentIndex(index)
        else:
            current_model = self.model_dropdown.currentText()
            if current_model in models:
                index = self.model_dropdown.findText(current_model)
                if index >= 0:
                    self.model_dropdown.setCurrentIndex(index)
                
    def test_api_connection(self):
        """Test the connection to the Ollama API"""
        self.test_api_btn.setEnabled(False)
        self.test_api_btn.setText("Testing...")
        
        def run_test():
            self.ollama_api.set_endpoint(self.api_endpoint.text().strip())
            models = self.ollama_api.get_models()
            
            if models:
                self.show_message("Connection Successful", 
                                  f"Successfully connected to Ollama API. Found {len(models)} models.",
                                  QMessageBox.Icon.Information)
                # Update models in the dropdown
                self.models = models
                self.update_model_list(models)
            else:
                self.show_message("Connection Failed", 
                                  "Failed to connect to Ollama API. Please check the endpoint and make sure Ollama is running.",
                                  QMessageBox.Icon.Warning)
                
            self.test_api_btn.setEnabled(True)
            self.test_api_btn.setText("Test Connection")
            
        threading.Thread(target=run_test).start()
        
    def show_message(self, title, message, icon):
        """Show a message box (safe for threading)"""
        # Can't directly show dialog from another thread
        # So we use a small delay to allow the main thread to handle it
        self.title = title
        self.message = message
        self.icon = icon
        
        # Schedule execution in the main thread
        QMetaObject.invokeMethod(
            self, "display_message", Qt.ConnectionType.QueuedConnection)
        
    def display_message(self):
        """Actually display the message box (called in main thread)"""
        QMessageBox.information(self, self.title, self.message, self.icon)
        
    def save_settings(self):
        """Save the current settings"""
        self.ollama_api.set_endpoint(self.api_endpoint.text().strip())
        # Save to config.json
        config_data = {
            "api_endpoint": self.api_endpoint.text().strip(),
            "model": self.model_dropdown.currentText(),
            "system_prompt": self.system_prompt.toPlainText().strip(),
            "show_thinking": self.show_thinking_checkbox.isChecked(),
            "theme": self.theme_dropdown.currentText(),
            "user_name": self.user_name_edit.text().strip(),
            "bot_name": self.bot_name_edit.text().strip(),
            "user_avatar": self.user_avatar_path,
            "bot_avatar": self.bot_avatar_path,
            "voice_model": self.voice_model_dropdown.currentText(),
        }
        save_config(config_data)
        # Reload config to ensure changes are reflected immediately
        from .config_manager import load_config
        self.config = load_config()
        # Emit signal to notify of settings update
        self.settings_updated.emit()
        QMessageBox.information(
            self,
            "Settings Saved",
            "Your settings have been saved.",
            QMessageBox.StandardButton.Ok
        )
        
    def on_api_error(self, error_msg):
        """Handle API errors"""
        QMessageBox.critical(
            self,
            "API Error",
            f"Ollama API error: {error_msg}",
            QMessageBox.StandardButton.Ok
        )
        
    def set_api_endpoint(self, endpoint):
        """Set the API endpoint text field"""
        self.api_endpoint.setText(endpoint)
        
    def set_model(self, model):
        """Set the selected model in the dropdown"""
        if model:
            index = self.model_dropdown.findText(model)
            if index >= 0:
                self.model_dropdown.setCurrentIndex(index)
                
    def set_system_prompt(self, prompt):
        """Set the system prompt text field"""
        self.system_prompt.setText(prompt)
        
    def get_api_endpoint(self):
        """Get the current API endpoint"""
        return self.api_endpoint.text().strip()
        
    def get_model(self):
        """Get the currently selected model"""
        return self.model_dropdown.currentText()
        
    def get_system_prompt(self):
        """Get the current system prompt"""
        return self.system_prompt.toPlainText().strip()
        
    def is_memory_enabled(self):
        """Check if memory is enabled"""
        return self.enable_memory.isChecked()
        
    def get_memory_location(self):
        """Get the memory storage location"""
        return self.memory_location.text().strip()
